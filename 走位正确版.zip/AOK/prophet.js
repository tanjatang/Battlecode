import {BCAbstractRobot, SPECS} from 'battlecode';
import nav from './nav.js';
import util from './util.js';
import PriorityQueue from './Priority_Queue.js';
//import Astar from './Astar.js';
//filter() 方法创建一个新的数组，新数组中的元素是通过检查指定数组中符合条件的所有元素。
//注意： filter() 不会对空数组进行检测。
//注意： filter() 不会改变原始数组。
const prophet = {}; //object

prophet.takeTurn = (self) => {
    self.log('prophet taking turn')
    self.log('START TURN ' + self.step);
    self.log('health: ' + self.me.health);
    
    var visible = self.getVisibleRobots(); 
    //this.getVisibleRobots(): Returns a list containing all robots within this.me's vision radius and 
    //all robots whose radio broadcasts can be heard (accessed via other_r.signal). 
    //For castles, robots of the same team not within the vision radius will also be included, 
    //to be able to read the castle_talk property.

    // get attackable robots
    var attackable = visible.filter((r) => {
        if (! self.isVisible(r)){
            return false; //if r is not visible, it cann't be attacked 
        }
        const dist = (r.x-self.me.x)**2 + (r.y-self.me.y)**2;
        if (r.team !== self.me.team
            && SPECS.UNITS[self.me.unit].ATTACK_RADIUS[0] <= dist
            && dist <= SPECS.UNITS[self.me.unit].ATTACK_RADIUS[1] ){
            return true; //if within the attack range, it is attackable
        }
        return false; //else return false?
    });

    const attacking = visible.filter(r => {
        if (r.team === self.me.team) {
            return false;  // cann't attack an ally
        }

        if (nav.sqDist(r, self.me) <= SPECS.UNITS[self.me.unit].ATTACK_RADIUS[0]) {
            return true; //the attack range of prophet is 1-16, so sqDist must be 1.
        } else {
            return false;
        }
    });

    if (attacking.length > 0) {
        const attacker = attacking[0];
        const dir = nav.getDir(self.me, attacker);//direction(dx,dy)
        const otherDir = {
            x: -dir.x,
            y: -dir.y,
        };
        return self.move(otherDir.x, otherDir.y);    //逃跑方向？？？
    }



    if(!self.pendingMessage) { //无pendingmessage，即下一个信息为x
        for(let i = 0; i < visible.length; i++ ) {
            const robot = visible[i];
            if (robot.team !== self.me.team && robot.unit === SPECS.CASTLE && self.enemyCastles.indexOf(robot.x * 64 + robot.y) < 0) {
                self.log('ENEMY CASTLE FOUND!');
                self.pendingMessage = robot.y;
                self.castleTalk(robot.x);
                self.enemyCastles.push(robot.x * 64 + robot.y);
            }
        }
    } else {
        self.castleTalk(self.pendingMessage);
        self.pendingMessage = null;
    }

    self.log('attackable list123456789' + attackable);

    if (attackable.length>0){
        // attack first robot
        var r = attackable[0];
        self.log('attackable[0]123456789' +r);
        self.log('attacking! ' + r + ' at loc ' + (r.x - self.me.x, r.y - self.me.y));
        return self.attack(r.x - self.me.x, r.y - self.me.y);
    }
    // self.log("Crusader health: " + self.me.health);'
    // if (!self.destination) { //若无destination，则用reflect来设置
    //     self.destination = nav.reflect(self.me, self.getPassableMap(), self.me.id % 2 === 0);
    // }

    if (!self.destination) {
        // need to figure out if 1st or 2nd pilgrim: if 1st get karb, else fuel
        
            // can see another pilgrim on my team
            self.resourceDestination = nav.getFarthestResource(self.me, self.getFuelMap());
            self.destination = self.resourceDestination;
    }
    var myObject = {
        x:0,
        y: 30,};
    const choice = nav.goto3(self,myObject,4);
   // const choice = nav.goto_test(self,myObject,self.getPassableMap(),self.getVisibleRobotMap()); 
    //const choice = nav.goto(self, self.destination);
    return self.move(choice.x, choice.y);
}


export default prophet;
