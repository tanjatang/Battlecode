import PriorityQueue from './Priority_Queue.js'
import priorityQueue from './Priority_Queue.js';
//import Astar from './castle.js';
const nav = {};
import Astar from './Astar_1.js'
//import Astar from './Script1.js';
nav.compass = [
    ['NW', 'N', 'NE'],
    ['W', 'C', 'E'],
    ['SW', 'S', 'SE'],
];

nav.rotateArr = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
nav.rotateArrInd = {
    'N': 0,
    'NE': 1,
    'E': 2,    
    'SE': 3,
    'S': 4,
    'SW': 5,
    'W': 6,
    'NW': 7,
};

nav.compassToCoordinate = {
    'N': {x: 0, y: -1},
    'NE': {x: 1, y: -1},
    'NW': {x: -1, y: -1},
    'E': {x: 1, y: 0},
    'W': {x: -1, y: 0},
    'S': {x: 0, y: 1},
    'SE': {x: 1, y: 1},
    'SW': {x: -1, y: 1},
};

//nav.Astar = (start, target,speed,robotMap,fullMap) =>{
//    const queue = priorityQueue;//neighbours list : cost F  + item Position
//    var g = [];
//    var count = 0;
//    var openList = [];
//   // var openList = [];
//    var h = Math.pow(nav.sqDist (start,target),0.5);
//    g.push({start:0});
//    var f_start = h;
//    queue.enqueue(start,f_start)
//    var cost = 0;
//    var path = [];
//    var destination_found = false;
//    while (!queue.isEmpty()&&destination_found===false){
//       var current = queue.dequeue();
 
//        var neighbours = nav.get_passable_Neighbours(current,fullMap,robotMap);
        
//        for (let i = 0;i<neighbours.length;i++) { //假如有位置可以移动
//            var next = neighbours[i];
//         var   g_value = g. current+speed;//更新next_G值
//            if(openList.indexOf(next)===-1 && g_value< g.next){//假如next没有被搜索过，或者G值,g.next是current的G
//                openList.push({next:current});// 加入待搜索列表
//                var next_g=g.next;
//                g.push({next_g:g_value});
//               var f_value = g_value+Math.pow(nav.sqDist (next,target),0.5);
//                queue.enqueue(next,f_value);
//                count ++;
            
//                if(current.x===target.x&&current.y===target.y){
//                    destination_found = true;
//                    cost = f_value;
//                    break;        
                
//                }
            
//            }
//                }  

//    }
//    path.push(target);
//    while(path.length<count){
//      var  last_position = openList.pop(0);
//        path.splice(0,0,last_position);
//    }
//    return {cost,path};
//}


nav.get_passable_Neighbours=(obj,self) =>{
    const x = obj.x;
    const y = obj.y;
    //const {x, y} = obj;
  
    var possibleNeighbours=[];
    var possible=[];
    for (let j = -1; j <= 1; j++){
        for (let i = -1; i <= 1; i++) {

            if (nav.isPassable({x:x+i, y:y+j}, self.getPassableMap(), self.getVisibleRobotMap())=== true ) {
                possibleNeighbours.push({x:x+i, y:y+j});
            }
        }

    }
    //for(let k =0; k<possibleNeighbours.length; k++){
    //    if(possibleNeighbours[k].x !==obj.x && possibleNeighbours[k].y !==obj.y){
    //        possible.push(possibleNeighbours[k]);
    //    }}
    return possibleNeighbours;
    // return possibleNeighbours;
}


nav.goto3 = (self, destination,speed) => {  ////顺序错了！！！！！！
    // if(self.me.x===destination.x&&self.me.y===destination.y){
    if(self.me.x===destination.x&&self.me.y===destination.y)
    {
        self.log("我已经在目的地上了");
        //next_step = [self.me.x,self.me.y];
        var newDir = {
            x: 0,
            y: 0,
        };
    }

    
        //nav.getResourceList(self.me,self.getKarboniteMap(),self.getFuelMap(),self.getVisibleRobotMap()).dequeue();
        //let new_destination=nav.getResourceList(self.me,self.getKarboniteMap(),self.getFuelMap(),self.getVisibleRobotMap()).dequeue();
        //const new_obj = Astar(self.me,new_destination,speed,self);
        //const new_cost = new_obj.cost;
        //const new_path = new_obj.path;
        //// const next=new_path;
        //var next_step =  new_path.shift();
        //self.log(next_step[0]+'  '+next_step[1]);
        //// var next_step = ;

        //  }


        // else if(destination === undefined || destination ===null || !destination ||nav.isPassable(destination,self.getPassableMap(),self.getVisibleRobotMap())===false)
        // {
        //else if( self.me.x!==destination.x&&self.me.y!==destination.y&&destination===undefined)
        //{

        //self.log("no destination 222222222222222222222222222222222222222");
        //    const dir = nav.get_passable_Neighbours(self.me,self.getPassableMap(), self.getVisibleRobotMap())[0];
        //    //const new_cost = new_obj.cost;
        //    var new_path = [];
        //    new_path.push([dir.x,dir.y]);
        //    var next_step = new_path.shift();  
        //   // next_step = [self.me.x,self.me.y];

        //}

    else //我不在目的地
    {
        if(nav.isPassable(destination,self.getPassableMap(),self.getVisibleRobotMap())===false)
        {//假如我不在目的地，我的目的地被人占了，我去下一个资源点
            self.log("destination is located by others，so i will go to a passable location");
            //  self.log("next step is undefined, so i will go to a passable location");
            //var passable = nav.get_passable_Neighbours(self.me,self.getPassableMap(), self.getVisibleRobotMap())[0];
            var nextResource=nav.getResourceList(self.me,self.getKarboniteMap(),self.getFuelMap(),self.getVisibleRobotMap()).dequeue();
            const nextDes = Astar(self.me,nextResource,speed,self);
            const choicePath=nextDes.path;
            var next_step = choicePath.shift();
            //var passable_loc=[passable.x,passable.y];
            //var newDir = {
            //    x: passable_loc[0] - self.me.x,
            //    y: passable_loc[1] - self.me.y,
            //};
        }

        else//假如我不在目的地，我的目的地没被占，我去找资源，但资源点可能undefined
        {
            const obj = Astar(self.me,destination,speed,self);
            const cost = obj.cost;
            const path = obj.path;
            var next_step = path.shift();  
        }
    
        //else if(nav.isPassable(destination,self.getPassableMap(),self.getVisibleRobotMap())===false&&destination.x!==self.me.x&&destination.y!==self.me.y){
        //    self.log("destination is located by others");
        //    nav.getResourceList(self.me,self.getKarboniteMap(),self.getFuelMap(),self.getVisibleRobotMap()).dequeue();
        //    let new_destination=nav.getResourceList(self.me,self.getKarboniteMap(),self.getFuelMap(),self.getVisibleRobotMap()).dequeue();
        //    const new_obj = Astar(self.me,new_destination,speed,self);
        //    const new_cost = new_obj.cost;
        //    const new_path = new_obj.path;
        //   // const next=new_path;
        //    var next_step =  new_path.shift();
        //    self.log(next_step[0]+'  '+next_step[1]);
        //   // var next_step = ;

        //}
        if(next_step!==undefined||nav.isPassable({x:next_step[0],y:next_step[1]},self.getPassableMap(),self.getVisibleRobotMap())===true)
        {//或
            var newDir = {
                x: next_step[0] - self.me.x,
                y: next_step[1] - self.me.y,
            };
        }
        else //这里再想想
        {
            self.log("next step is undefined, so i will go to a passable location");
            var passable = nav.get_passable_Neighbours(self.me,self.getPassableMap(), self.getVisibleRobotMap())[0];
            var passable_loc=[passable.x,passable.y];
            var newDir = {
                x: passable_loc[0] - self.me.x,
                y: passable_loc[1] - self.me.y,
            };

        }
    }
        
    ////////////////////////////////////////////////////////
    if (newDir.x < 0) 
    {
        newDir.x = -1;
    } 
    else if (newDir.x > 0) 
    {
        newDir.x = 1;
    }

    if (newDir.y < 0) 
    {
        newDir.y = -1;
    } 
    else if (newDir.y > 0) 
    {
        newDir.y = 1;
    }

    if(newDir.x===0&&newDir.y===0){
        newDir={x:0,y:0}
    }

    // }
    //////////////////////////////////////////
    self.log('ROBOT LOCATION IS '+self.me.x+" " +self.me.y);
    self.log('next step location  is '+next_step);
    self.log('next dir is'+newDir.x+newDir.y);
    return newDir;
  
};







nav.goto_test1 = (self, destination,speed) => {
    // Astar(self.me,destination,speed,self);
    if(self.me.x=destination.x&&self.me.y===destination.y)//假如我在目的地
    {
        self.log("我在矿山啦啦啦啦啦啦啦啦");

        return {x:0,y:0};
    }
    else//假如我不在目的地
    {
        const obj = Astar(self.me,destination,speed,self);
        const cost = obj.cost;
        const path = obj.path;
        var next_step = path.shift(); 
        var next={x:next_step[0],y:next_step[1]};

        var goalDir = nav.getDir(self.me, next);
        self.log("next is "+next.x+" "+next.y);
        self.log("goalDir is"+goalDir.x+" "+goalDir.y);
        self.log("RObot location is "+self.me.x+" "+self.me.y);

        //let tryDir = 0;
        if (!nav.isPassable(
           next,self.getPassableMap(),self.getVisibleRobotMap()
        )) //假如下一步被占，我走别的可能的位置
        {
            var change = nav.get_passable_Neighbours(self.me,self)[0];
            var goalDir = nav.getDir(self.me, change);
           //var goalDir = nav.rotate(goalDir, 1);
            //tryDir++;
            self.log('下一步不可走，goalDir是'+goalDir.x+" "+goalDir.y);
            self.log('xiayigezoudedifangshi '+ change.x+" "+change.y);
        }
        self.log("下一步没被张，我可以走，方向是"+goalDir.x+goalDir.y);
        return goalDir;
    }
};

nav.goto_test2 = (self, destination,speed) => {
    // Astar(self.me,destination,speed,self);
    if(self.me.x=destination.x&&self.me.y===destination.y)
    {
        self.log("我在矿山啦啦啦啦啦啦啦啦");
        return {x:0,y:0};
    }
    else
    {
        const obj = Astar(self.me,destination,speed,self);
        const cost = obj.cost;
        const path = obj.path;
        var next_step = path.shift(); 
        var next={x:next_step[0],y:next_step[1]};
        let goalDir = nav.getDir(self.me, next);
        self.log("goalDir is"+goalDir.x+" "+goalDir.y);
        self.log("RObot location is "+self.me.x+" "+self.me.y);
        //if (goalDir.x === 0 && goalDir.y === 0) 
        //{
        //    return goalDir;
        //}
        //if(!nav.isPassable(
        //     nav.applyDir(self.me, goalDir),
        //     fullMap,robotMap
        // ))
        //{

        //}
        let tryDir = 0;
        while (!nav.isPassable(
            nav.applyDir(self.me, goalDir),
            self.getPassableMap(),self.getVisibleRobotMap()
        ) && tryDir < 8) 
        {
            goalDir = nav.rotate(goalDir, 1);
            tryDir++;
        }

        return goalDir;
    }
};


nav.goto = (self, destination,speed,robotMap,fullMap) => {  ////顺序错了！！！！！！

    const obj = Astar(self.me,destination,speed,self);
   
    const cost = obj.cost;
    const path = obj.path;
    
    const next_step = path.pop(0);
    const newDir = {
        x: next_step.x - self.me.x,
        y: next_step.y - self.me.y,
    };
    self.log('A***************************************');
    if (newDir.x < 0) {
        newDir.x = -1;
    } else if (newDir.x > 0) {
        newDir.x = 1;
    }

    if (newDir.y < 0) {
        newDir.y = -1;
    } else if (newDir.y > 0) {
        newDir.y = 1;
    }

    return newDir;


    //let goalDir = nav.getDir(self.me, destination,speed,robotMap,fullMap);
    //if (goalDir.x === 0 && goalDir.y === 0) {
    //    return goalDir;
    //}
    //let tryDir = 0;
    //while (!nav.isPassable(
    //    nav.applyDir(self.me, goalDir), 
    //    self.getPassableMap(), 
    //    self.getVisibleRobotMap()
    //) && tryDir < 8) {
    //    goalDir = nav.rotate(goalDir, 1); //若getdir第一次返回的dx，dy加上初始位置得到的空格并不能通过，则加1，依次试验8种方向。
    //    tryDir++;
    //}
    //return goalDir;
};



nav.toCompassDir = (dir) => {
    return nav.compass[dir.y + 1][dir.x + 1];  //第（y+1）行，第（x+1）列，N代表第0行，第1列，此函数return dir对应的方向
};

nav.toCoordinateDir = (dir) => {
    return nav.compassToCoordinate[dir]; //return dir对应的dx，dy整数值
};

nav.rotate = (dir, amount) => {
    const compassDir = nav.toCompassDir(dir); // compassdir为N，E, W这种字符串
    const rotateCompassDir = nav.rotateArr[(nav.rotateArrInd[compassDir] + amount) % 8];
    return nav.toCoordinateDir(rotateCompassDir);  // rotateCompassDir也是字符串，最后返回该字符串对应的dx，dy
};

nav.reflect = (loc, fullMap, isHorizontalReflection) => {
    const mapLen = fullMap.length;  // height is equal to width
    const hReflect = {  //水平翻转
        x: loc.x,
        y: mapLen - loc.y,
    };
    const vReflect = {  //竖直翻转
        x: mapLen - loc.y,
        y: loc.y,
    };

    if (isHorizontalReflection) {
        return fullMap[hReflect.y][hReflect.x] ? hReflect : vReflect;
        //若fullMap[hReflect.y][hReflect.x]不为0或者为真，return hReflect，否则return vReflect
    } else {
        return fullMap[vReflect.y][vReflect.x] ? vReflect : hReflect;
    }
};

 nav.getDir = (start, target) => {
     const newDir = {
         x: target.x - start.x,
         y: target.y - start.y,
     };

     if (newDir.x < 0) {
         newDir.x = -1;
     } else if (newDir.x > 0) {
         newDir.x = 1;
     }

     if (newDir.y < 0) {
         newDir.y = -1;
     } else if (newDir.y > 0) {
         newDir.y = 1;
     }

     return newDir;
 };

//nav.getDir = (start,target,speed,robotMap,fullMap)=>{ //2.0 Version
////nav.goto = (start,target,speed,robotMap,fullMap)=>{ //2.0 Version
   
//   const obj = nav.Astar(start,target,speed,robotMap,fullMap);
//   const cost = obj.cost;
//   const path = obj.path;

//  const next_step = path.pop(0);
//   const newDir = {
//       x: next_step.x - start.x,
//       y: next_step.y - start.y,
//   };

//   if (newDir.x < 0) {
//       newDir.x = -1;
//   } else if (newDir.x > 0) {
//       newDir.x = 1;
//   }

//   if (newDir.y < 0) {
//       newDir.y = -1;
//   } else if (newDir.y > 0) {
//       newDir.y = 1;
//   }

//   return newDir;

//}

nav.isPassable = (loc, fullMap, robotMap) => {
    const {x, y} = loc;
    const mapLen = fullMap.length;
    if (x >= mapLen || x < 0) {
        return false;
    } else if (y >= mapLen || y < 0) {
        return false;
    } else if (robotMap[y][x] > 0 || !fullMap[y][x]) {
        return false;
    } else {
        return true;
    }
};

nav.get_passable_Neighbours = (obj,self) => {

    const x = obj.x;
    const y = obj.y;
    //const {x, y} = obj;
  
    var possibleNeighbours=[];
    var possible=[];
    for (let j = -1; j <= 1; j++){
        for (let i = -1; i <= 1; i++) {

            if (nav.isPassable({x:x+i, y:y+j}, self.getPassableMap(), self.getVisibleRobotMap())=== true ) {
                possibleNeighbours.push({x:x+i, y:y+j});
            }
        }

    }
    //for(let k =0; k<possibleNeighbours.length; k++){
    //    if(possibleNeighbours[k].x !==obj.x && possibleNeighbours[k].y !==obj.y){
    //        possible.push(possibleNeighbours[k]);
    //    }}
    //return possible;
    return possibleNeighbours;


///////////////////////////////////////////////////////////////////////////////////
    //const {x,y} = loc.me;
    //var passable_neighbours = [];
    //for (let j = -1; j <= 1; j++){
    //    for (let i = -1; i <= 1; i++) {
    //        if (nav.isPassable({x:x+i, y:y+j}, fullMap, robotMap) === true) {
    //            //if (loc.map[y+i][x+j] === true) { 
    //            passable_neighbours.push({x:x+i, y:y+j});
    //        }}
    //} 
    //return passable_neighbours;
}





//nav.get_passable_Neighbours = (loc,fullMap,RobotMap) => {
//    const x = loc.x;
//    const y = loc.y;
//    var possibleNeighbours=[];
//    for (let j = -1; j <= 1; j++){
//        for (let i = -1; i <= 1; i++) {
                  
//            if (self.map[y+j][x+i] === true) {
//                possibleNeighbours.push({x:x+i, y:y+j});
//            }
                
//        }


//    }
//    return possibleNeighbours;
//}

nav.goto_test = (self, destination,fullMap,robotMap) => {
    let goalDir = nav.getDir(self.me, destination);
    if (goalDir.x === 0 && goalDir.y === 0) {
        return goalDir;
    }
    let tryDir = 0;
    while (!nav.isPassable(
    nav.applyDir(self.me, goalDir),
    fullMap,robotMap
    ) && tryDir < 8) {
        goalDir = nav.rotate(goalDir, 1);
        tryDir++;
    }
    return goalDir;
};

nav.applyDir = (loc, dir) => { //返回加了方向之后的loc，但是还是停留在原处
    return {
        x: loc.x + dir.x,
        y: loc.y + dir.y,
    };
};



nav.sqDist = (start, end) => {
    return Math.pow(start.x - end.x, 2) + Math.pow(start.y - end.y, 2);
};

nav.getClosestKarbonite = (loc, karbMap) => {   //最近的资源点，包括K和Fuel
    const mapLen = karbMap.length;
    let closestLoc = null;
    let closestDist = 100000; // Large number;
    for (let y = 0; y < mapLen; y++) {
        for (let x = 0; x < mapLen; x++) {
            if (karbMap[y][x] && nav.sqDist({x,y}, loc) < closestDist) {
                closestDist = nav.sqDist({x,y}, loc);
                closestLoc = {x,y};
            }
        }
    }
    return closestLoc;
};

nav.getFarthestResource = (loc, karbMap) => {   //最yuan的资源点，包括K和Fuel
    const mapLen = karbMap.length;
    let FarthestLoc = null;
    let farthestDist = 1; // Large number;
    for (let y = 0; y < mapLen; y++) {
        for (let x = 0; x < mapLen; x++) {
            if (karbMap[y][x] && nav.sqDist({x,y}, loc) > farthestDist) {
                farthestDist = nav.sqDist({x,y}, loc);
                FarthestLoc = {x:x,y:y};
            }
        }
    }
    return FarthestLoc;
};
export default nav;
