const preacher = {};

export default preacher;
