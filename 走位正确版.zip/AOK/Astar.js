﻿// JavaScript source code
import PriorityQueue from './Priority_Queue.js'
import priorityQueue from './Priority_Queue.js';
import nav from './nav.js';

function HashMap(){  

            //定义长度  
            var length = 0;  
            //创建一个对象  
            var obj = new Object();  
 
            /** 
            * 判断Map是否为空 
            */  
            this.isEmpty = function(){  
                return length == 0;  
            };  
 
            /** 
            * 判断对象中是否包含给定Key 
            */  
            this.containsKey=function(key){  
                return (key in obj);  
            };  
 
            /** 
            * 判断对象中是否包含给定的Value 
            */  
            this.containsValue=function(value){  
                for(var key in obj){  
                    if(obj[key] == value){  
                        return true;  
                    }  
                }  
                return false;  
            };  
 
            /** 
            *向map中添加数据 
            */  
            this.put=function(key,value){  
                if(!this.containsKey(key)){  
                    length++;  
                }  
                obj[key] = value;  
            };  
 
            /** 
            * 根据给定的Key获得Value 
            */  
            this.get=function(key){  
                return this.containsKey(key)?obj[key]:null;  
            };  
 
            /** 
            * 根据给定的Key删除一个值 
            */  
            this.remove=function(key){  
                if(this.containsKey(key)&&(delete obj[key])){  
                    length--;  
                }  
            };  
 
            /** 
            * 获得Map中的所有Value 
            */  
            this.values=function(){  
                var _values= new Array();  
                for(var key in obj){  
                    _values.push(obj[key]);  
                }  
                return _values;  
            };  
 
            /** 
            * 获得Map中的所有Key 
            */  
            this.keySet=function(){  
                var _keys = new Array();  
                for(var key in obj){  
                    _keys.push(key);  
                }  
                return _keys;  
            };  
 
            /** 
            * 获得Map的长度 
            */  
            this.size = function(){  
                return length;  
            };  
 
            /** 
            * 清空Map 
            */  
            this.clear = function(){  
                length = 0;  
                obj = new Object();  
            };  
        }
 
            //////////////////////////////////////////////////////////////////////////////////////////////
function get_passable_Neighbours(loc,self) {
    const x = loc.x;
    const y = loc.y;
    var possibleNeighbours=[];
    var possible=[];
    for (let j = -1; j <= 1; j++){
        for (let i = -1; i <= 1; i++) {
            if (self.map[y+j][x+i] === true ) {
                possibleNeighbours.push({x:x+i, y:y+j});
            }
        }

    }
    //for(let k =0; k<possibleNeighbours.length; k++){
    //    if(possibleNeighbours[k].x !==loc.x && possibleNeighbours[k].y !==loc.y){
    //        possible.push(possibleNeighbours[k]);
    //    }}
    return possibleNeighbours;
}

            ////////////////////////////////////////////////////////////////////////////////////////


    ////////////////////////////////////////////////////////////////////////////////////

            function Astar(start, target,speed,self){
                const queue = priorityQueue;//neighbours list : cost F  + item Position
                const target_loc=[target.x,target.y];
                var g = new HashMap();
                var count = 0;
                var closeList = new HashMap();
                // closeList[start]=null;
               const  start_loc=[start.x,start.y];
              closeList.put(start_loc,100000);
             
                 //self.log("测试键值取values9999999999999999999999999999999"+"ooooooo"+"ppppppppppppppp");
            //  }
               var h = Math.abs(start.x-target.x)+ Math.abs(start.y-target.y);
              self.log("start position uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"+start.x+" "+start.y);
                g.put(start,0);
                var f_start = h;
                queue.enqueue(start,f_start)
                var cost = 0;
                var path = [];
                var destination_found = false;
                while (queue.isEmpty()===false&& destination_found===false){
                    let current = queue.dequeue();
                    var current_loc = [current.x,current.y];
                 //  self.log("current-----------------------------------------"+current.x+' '+current.y);
                   let neighbours = get_passable_Neighbours(current,self);
                    
                   for (let k=0;k<neighbours.length;k++)
                   {
                       self.log("neighbours length 99999999999999999999999999999999999999"+'   '+neighbours[k]);
                       self.log("neighbours length 99999999999999999999999999999999999999"+'   '+neighbours.length);
                   }
                   //let neighbours = nav.get_passable_Neighbours(current);
                  //  self.log("neighbours 99999999999999999999999999999999999999"+neighbours);
                    //  g.push({current:count});
                    for (let i = 0;i<neighbours.length;i++) { //假如有位置可以移动
                       
                        var next = neighbours[i];
                        let next_loc=[next.x,next.y];
                       // let current_loc=[current.x,current.y];
                     //   self.log("next55555555555555555555555555555555555555555"+next.x+' '+next.y);
                        var g_value = g.get(current)+speed;//更新next_G值
                        //  g[next]=g_value;
                        //if(closeList.containsValue(next)===false){
                        //self.log("g value current-----------------------------------------"+g.get(current));
                        //    self.log("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"+g_value+Math.pow(nav.sqDist (next,target),0.5)+'   '+g[current]+Math.pow(nav.sqDist (current,target),0.5));
                        //} 
                        ////////////////////////////////////////////////////////////////////////////////////////////////
                    

                        //888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
                      //if(closeList.containsValue(next)===false&& g_value+Math.abs(next.x-target.x)+ Math.abs(next.y-target.y)<g.get(current)+Math.abs(current.x-target.x)+ Math.abs(current.y-target.y)){//不在closelist
                          if(closeList.containsValue(next_loc)===false && g_value<g.get(current)){
                    
                           //self.log("执行添加操作\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
                            const f_value = g_value+Math.pow(nav.sqDist (next,target),0.5);
                            queue.enqueue(next,f_value);
                       //     self.log("closeList length is@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+closeList.size());
                            //closeList.push(current);
                            count ++;
                            g.put(next,g_value);
                       
                            //closeList[next]=current;
                     
                            closeList.put(next_loc,current_loc);
                           // self.log("closeList length is@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+closeList.size());
                            //self.log("open list values.........................................>>>>>>>>>>>>>>>>>>>>>>>"+closeList.values());
                        }
                      //else if(self.map[next.x][next.y]===false){
                      //    continue;
                      //}
                      if(next.x===target.x&&next.y===target.y){
                          destination_found = true;
                         self.log("find path！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！");
                          //cost = f_value;
                          break;        
                      }

                    }  

                }
          
                path.push(target_loc);

                while(path.length<g_value){
                   let key=path[0];
              
                //   const key_loc=[key.x,key.y];
                 //  self.log("key is %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+key);
                   let  last_position = closeList.get(key);
                   self.log("last position%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+last_position);
                   self.log("target position%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+target_loc);
               
                    //if(last_position.length>0){
                   if(last_position!==100000){
                        //path.push(last_position);
                        path.splice(0,0,last_position);
                      //  self.log("path 6666666666666666666666666666666666666666666 path"+path.length);
                    }
                    else{
                      
                        break;
                    }
               
                }
                path.shift();
                return {cost,path};
            }

/////////////////////////////////////////////////////////////////////////////////////
export default Astar;
//export default get_passable_Neighbours;