import {BCAbstractRobot, SPECS} from 'battlecode';
import nav from './nav.js';
import util from './util.js';
//import Astar from './Astar.js';
import Astar from './Astar_1.js';
//import Astar from './Script1.js';
import get_passable_Neighbours from  './Astar.js';
import PriorityQueue from './Priority_Queue.js'
import priorityQueue from './Priority_Queue.js';

const castle = {};

castle.takeTurn = (self) => {
    self.log('castle taking turn')
    const visible = self.getVisibleRobots();
    const messagingRobots = visible.filter(robot => {
        return robot.castle_talk;
    });

   
//       ///////////////////////////////////////////////////////
    
//    function HashMap(){  

//        //定义长度  
//        var length = 0;  
//        //创建一个对象  
//        var obj = new Object();  
 
//        /** 
//        * 判断Map是否为空 
//        */  
//        this.isEmpty = function(){  
//            return length == 0;  
//        };  
 
//        /** 
//        * 判断对象中是否包含给定Key 
//        */  
//        this.containsKey=function(key){  
//            return (key in obj);  
//        };  
 
//        /** 
//        * 判断对象中是否包含给定的Value 
//        */  
//        this.containsValue=function(value){  
//            for(var key in obj){  
//                if(obj[key] == value){  
//                    return true;  
//                }  
//            }  
//            return false;  
//        };  
 
//        /** 
//        *向map中添加数据 
//        */  
//        this.put=function(key,value){  
//            if(!this.containsKey(key)){  
//                length++;  
//            }  
//            obj[key] = value;  
//        };  
 
//        /** 
//        * 根据给定的Key获得Value 
//        */  
//        this.get=function(key){  
//            return this.containsKey(key)?obj[key]:null;  
//        };  
 
//        /** 
//        * 根据给定的Key删除一个值 
//        */  
//        this.remove=function(key){  
//            if(this.containsKey(key)&&(delete obj[key])){  
//                length--;  
//            }  
//        };  
 
//        /** 
//        * 获得Map中的所有Value 
//        */  
//        this.values=function(){  
//            var _values= new Array();  
//            for(var key in obj){  
//                _values.push(obj[key]);  
//            }  
//            return _values;  
//        };  
 
//        /** 
//        * 获得Map中的所有Key 
//        */  
//        this.keySet=function(){  
//            var _keys = new Array();  
//            for(var key in obj){  
//                _keys.push(key);  
//            }  
//            return _keys;  
//        };  
 
//        /** 
//        * 获得Map的长度 
//        */  
//        this.size = function(){  
//            return length;  
//        };  
 
//        /** 
//        * 清空Map 
//        */  
//        this.clear = function(){  
//            length = 0;  
//            obj = new Object();  
//        };  
//    }
 
//        //////////////////////////////////////////////////////////////////////////////////////////////
//        function get_passable_Neighbours(loc) {
//            const x = loc.x;
//            const y = loc.y;
//            var possibleNeighbours=[];
//            for (let j = -1; j <= 1; j++){
//                for (let i = -1; i <= 1; i++) {
                  
//                    if (self.map[y+j][x+i] === true) {
//                        possibleNeighbours.push({x:x+i, y:y+j});
//                    }
                
//                }


//            }
//            return possibleNeighbours;
//        }

//        ////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////

//        function Astar(start, target,speed){
//            const queue = priorityQueue;//neighbours list : cost F  + item Position
//            const target_loc=[target.x,target.y];
//            var g = new HashMap();
//            var count = 0;
//            var openList = new HashMap();
//            // openList[start]=null;
//          const  start_loc=[start.x,start.y];
//          openList.put(start_loc,100000);
//            /////////////////////
//        //  var  dic = new HashMap();
//        //  const se_loc=[2,3];
//        //  const th_loc=[4,5];
//        //  const f_loc=[6,7];
//        //  dic.put(start_loc,target_loc);
//        // // dic.put(th_loc,f_loc);

//        //  //const v= dic.get(se_loc);
//        //    //const p=dic.get(v);
//        //let j=dic.get(start_loc)
//        //  if(j===target_loc){
//        //      self.log("测试键值取values9999999999999999999999999999999"+"ooooooo"+"ppppppppppppppp");
//        //  }
//            var h = Math.abs(start.x-target.x)+ Math.abs(start.y-target.y);
//            self.log("start position uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"+start.x+" "+start.y);
//            g.put(start,0);
//            var f_start = h;
//            queue.enqueue(start,f_start)
//            var cost = 0;
//            var path = [];
//            var destination_found = false;
//            while (queue.isEmpty()===false&& destination_found===false){
//                let current = queue.dequeue();
//                var current_loc = [current.x,current.y];
//               self.log("current-----------------------------------------"+current.x+' '+current.y);
//               let neighbours = get_passable_Neighbours(current);
              

//               //let neighbours = nav.get_passable_Neighbours(current);
//              //  self.log("neighbours 99999999999999999999999999999999999999"+neighbours);
//                //  g.push({current:count});
//                for (let i = 0;i<neighbours.length;i++) { //假如有位置可以移动

//                    var next = neighbours[i];
//                    let next_loc=[next.x,next.y];
//                    let current_loc=[current.x,current.y];
//                 //   self.log("next55555555555555555555555555555555555555555"+next.x+' '+next.y);
//                    var g_value = g.get(current)+speed;//更新next_G值
//                    //  g[next]=g_value;
//                    //if(openList.containsValue(next)===false){
//                    //self.log("g value current-----------------------------------------"+g.get(current));
//                    //    self.log("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"+g_value+Math.pow(nav.sqDist (next,target),0.5)+'   '+g[current]+Math.pow(nav.sqDist (current,target),0.5));
//                    //} 
//                    ////////////////////////////////////////////////////////////////////////////////////////////////
                    

//                    //888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
//                  if(openList.containsValue(next)===false&& g_value+Math.abs(next.x-target.x)+ Math.abs(next.y-target.y)<g.get(current)+Math.abs(current.x-target.x)+ Math.abs(current.y-target.y)){//不在openList
//                     // if(openList.containsValue(next)===false && g_value<g.get(next)){
                    
//                       self.log("执行添加操作\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
//                        const f_value = g_value+Math.pow(nav.sqDist (next,target),0.5);
//                        queue.enqueue(next,f_value);
//                        self.log("openList length is@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+openList.size());
//                        //openList.push(current);
//                        count ++;
//                        g.put(next,g_value);
                       
//                        //openList[next]=current;
                     
//                        openList.put(next_loc,current_loc);
//                       // self.log("openList length is@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+openList.size());
//                        //self.log("open list values.........................................>>>>>>>>>>>>>>>>>>>>>>>"+openList.values());
//                    }
//                  //else if(self.map[next.x][next.y]===false){
//                  //    continue;
//                  //}
//                  if(next.x===target.x&&next.y===target.y){
//                      destination_found = true;
//                      self.log("找到路径了！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！");
//                      //cost = f_value;
//                      break;        
//                  }

//                    //99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999

//                    //if(openList.indexOf(next)===-1 && g_value+Math.pow(nav.sqDist (next,target),0.5)>g[current]+Math.pow(nav.sqDist (current,target),0.5)){//假如next没有被搜索过，或者G值,g.next是current的G
//                    //    openList.push(next);// 加入待搜索列表
//                    //    var next_g=g[next];
//                    //    self.log("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
//                    //    g[next_g]=g_value;
//                    //    var f_value = g_value+Math.pow(nav.sqDist (next,target),0.5);
//                    //    queue.enqueue(next,f_value);
//                    //    count ++;
//                    //let next_loc=[next.x,next.y];
                   
            
//                    //}

//                }  

//            }
          
//            path.push(target_loc);
//            //var last_position=target;
//            //var last_loc=[last_position.x,last_position.y];
            
//          // let len=length(openList);
          
//           // const l=path[0];
//           //const k =openList.find(l);
//           //self.log("di o ge yuan su shi shen me ne"+k.x+k.y);
//            self.log("target..........................................."+target.x+"  "+target.y)
//            //while(last_loc!==start_loc){
//            //    var key_last=path[0];
//            //    var key_last_loc = [key_last.x,key_last.y];
//            //    last_position = openList.get(key_last_loc);
//            //    last_loc=[last_position.x,last_position.y];
//            //    path.splice(0,0,last_position);
//            //    self.log("last position%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+last_position); 
//            //    self.log("path 6666666666666666666666666666666666666666666 path"+path[0]+path[1]);
//            //}



//            while(path.length<g_value){
//               let key=path[0];
              
//            //   const key_loc=[key.x,key.y];
//             //  self.log("key is %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+key);
//               let  last_position = openList.get(key);
//               self.log("last position%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+last_position);
               
//                //if(last_position.length>0){
//               if(last_position!==100000){
//                    //path.push(last_position);
//                    path.splice(0,0,last_position);
//                  //  self.log("path 6666666666666666666666666666666666666666666 path"+path.length);
//                }
//                else{
//                   // self.log("find the path!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
//                    self.log("path length is?????????????????????????????????????????"+path.length);
                   
//                  //  const soll_s=path.pop();
//                  //  const soll_s_1=path.pop();
                   
//                    break;
//                }
               
//            }
//            return {cost,path};
//        }
//let loc = [self.me.x,self.me.y]
//let searchMap = nav.getClosestKarbonite(loc,SPECS.PROPHET.karbonite_map);
////        //let myObject = {
////        //    a:searchMap.x,
////        //    b:searchMap.y
////        //};
////        var myObject = {
////            x:self.me.x+10,
////            y: self.me.y+10,};
           
//   self.log('searchMap    ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp'+searchMap.x);
       
//        
//        //const path1=obj.path;
          
    if (self.karbonite > 1) {  
           
            var myObject = {
                            x:self.me.x+18,
                            y: self.me.y+8,};
           
           //let obj=Astar(self.me,myObject,1,self);

           
            


        //    self.log('myObject    ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp'+myObject);

            let possible = nav.get_passable_Neighbours(self.me,self);
            var loc = possible[0];

            //self.log('building a prophet at ' + nav.getDir(self.me,myObject).x + ',' + ( nav.getDir(self.me,myObject).y));
        //return self.buildUnit(SPECS.PROPHET, nav.getDir(self.me,myObject).x, nav.getDir(self.me,myObject).y);
           self.log('castle location ' + self.me.x + ',' + self.me.y);
           self.log('building a prophet at ' + loc.x + ',' + loc.y);
           self.log('possible neighbours length ' + possible.length);
        return self.buildUnit(SPECS.PROPHET, loc.x-self.me.x, loc.y-self.me.y);
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
  

    
        //pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp































//    for (let i = 0; i < messagingRobots.length; i++) {
//        const robot = messagingRobots[i];
//        if (!self.pendingRecievedMessages[robot.id]) {
//            self.pendingRecievedMessages[robot.id] = robot.castle_talk;
//        } else {
//            self.enemyCastles.push({
//                x: self.pendingRecievedMessages[robot.id],
//                y: robot.castle_talk,
//            });
//            self.pendingRecievedMessages[robot.id] = null;
//        }
//    }
//    //uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu

//    var visibleEnemyRobot = visible.filter((r) => {    //fund enemys
//        if (! self.isVisible(r)|| r.team===self.me.team||r.id===self.me.id){
//            return false; //
//        }});




//    if(visibleEnemyRobot.length>0){

       
//        for(let i = 0; i < visibleEnemyRobot.length; i++)
//        {
//            const  robot = visibleEnemyRobot[0];
//            if (robot.team !== self.me.team)                       //假如可见敌人
         
//            {
//                self.signal(robot.x*64+robot.y,400);//发消息

//                var myvisiblerobot = visible.filter((my)=>{//找出我方士兵
//                    if(my.team===self.me.team && my.id!==self.me.id){
//                        return true;
//                    }
//                });


//                if(!myvisiblerobot){//无己方士兵
//                    if(self.fuel>=65&&self.karbonite>=30){
//                        self.log('building a prophet at ' + (self.me,robot).x + ',' + ( nav.getDir(self.me,robot).yx));
//                        return self.buildUnit(SPECS.PROPHET, nav.getDir(self.me,robot).x, nav.getDir(self.me,robot).y);
//                    }
//                    else{
//                        self.log('building a crusader at ' + (self.me,robot).x + ',' + ( nav.getDir(self.me,robot).yx));
//                        return self.buildUnit(SPECS.CRUSADER, nav.getDir(self.me,robot).x, nav.getDir(self.me,robot).y);
//                    }
//                }

           
//            }}}


//    else{//假如没看到敌人
//        if (self.pilgrimsBuilt < 7 && self.fuel >= 200) {  //  
               
//            self.pilgrimsBuilt++;
//            let possibleloc1=get_passable_Neighbours(self.me,self.getPassableMap(),self.getVisibleRobotMap());
//            self.log('building a pilgrim at ' + (possibleloc1[0].x-self.me.x) + ',' + (possibleloc1[0].y-self.me.y));
//            //iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii
//            //const obj = nav.Astar(self.me,possibleloc1[0],speed,robotMap,fullMap);
           
//            //const cost = obj.cost;
//            //const path = obj.path;


//            //   self.log('jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj'+path);
//            //   self.log('oooooooooooooooooooooooooooooooooooooooooooooooooooooo'+path[0]+','+path[1]);
//            //0000000000000000000000000000000000000000000000000000000000000
//            return self.buildUnit(SPECS.PILGRIM, possibleloc1[0].x-self.me.x, possibleloc1[0].y-self.me.y);
//        } 
//        else if(self.fuel>=150){
//            let possibleloc=get_passable_Neighbours(self.me,self.getPassableMap(),self.getVisibleRobotMap());
  
           
//            self.log('building a crusader at ' + (possibleloc[0].x-self.me.x) + ',' + (possibleloc[0].y-self.me.y));
//            return self.buildUnit(SPECS.CRUSADER, possibleloc[0].x-self.me.x, possibleloc[0].y-self.me.y);
//        }
//    }
        
////}



//    //yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy

//    if (self.step % 100) {
//        // self.log('KNOWN ENEMY CASTLES: ');
//        for(let i = 0; i < self.enemyCastles.length; i++) {
//            const {x,y} = self.enemyCastles[i];
//            self.log(x + ',' + y);
//        }
//    }};

////    if (self.pilgrimsBuilt < 2 && self.karbonite >= 100) {  // pilgrimsBuilt 未定义？？？ 
////        self.log('Building a pilgrim at ' + (self.me.x+1) + ',' + (self.me.y+1));
////        self.pilgrimsBuilt++;
////        return self.buildUnit(SPECS.PILGRIM, 1, 0);
////    } 

////    if (self.karbonite > 200) {
////         const unitEnum = Math.floor(Math.random() * 3);
////         let unit = null;
////         switch(unitEnum) {
////         case 0:
////             unit = SPECS.CRUSADER;
////             self.log('Building a crusader at ' + (self.me.x+1) + ',' + (self.me.y+1));
////             break;
////         case 1:
////             unit = SPECS.PROPHET;
////             self.log('Building a prophet at ' + (self.me.x+1) + ',' + (self.me.y+1));
////             break;
////         case 2:
////             unit = SPECS.PREACHER;
////             self.log('Building a preacher at ' + (self.me.x+1) + ',' + (self.me.y+1));
////             break;
////         }
////        return self.buildUnit(SPECS.PROPHET, 1, 0);
////    }
};


export default castle;
